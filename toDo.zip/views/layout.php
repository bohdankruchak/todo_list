<DOCTYPE html>
<html>
  <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="scripts.js"></script>
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>
    <?php 
        require_once('routes.php'); 
    ?>
    <div class="wait"><!-- Wait loader --></div>
  <body>
<html>